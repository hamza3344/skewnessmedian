﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace skewmedian
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> mylist = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                mylist.Add(double.Parse(s));
            }
            int half = mylist.Count() / 2;
            double median = (mylist.Count() % 2 == 0) ? (mylist.OrderBy(n => n).ElementAt(half) +
                mylist.OrderBy(n => n).ElementAt(half - 1)) / 2 : mylist.OrderBy(n => n).ElementAt(half);
            double mean = mylist.Average();
            double stdmean = Math.Sqrt(mylist.Sum(x => Math.Pow(x - mylist.Average(), 2)) / mylist.Count());
            double skemedian = (3 * (mean - median)) / stdmean;
            MessageBox.Show("" + skemedian);
        }
    }
}
